package kendaraan.util;

public interface flyble {
    void fly();
}

