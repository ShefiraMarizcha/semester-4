package kendaraan.util;

public interface ShootAble<String> {
    void shoot(String vehicle);
}
