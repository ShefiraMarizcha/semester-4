package exception.custom;

public class IllegalAdminAcces extends Exception{
    public IllegalAdminAcces(String message){
        super(message);
    }
}